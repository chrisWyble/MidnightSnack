﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ButtonHandler : MonoBehaviour
{
    public GameObject bat;
    public GameObject timer;

    public void StartGame()
    {
        bat.GetComponent<BatBehavior>().SetPause(false);
        timer.GetComponent<TimerScript>().SetPause(false);

        bat.transform.position = new Vector3(0f,45f,-250f);
        bat.transform.eulerAngles = new Vector3(0f,0f,0f);
    }
    
    public void QuitGame()
    {
        Application.Quit();
    }
}
