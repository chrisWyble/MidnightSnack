﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ForestBehavior : MonoBehaviour
{

    public int fruitCountSpawned = 4;

    GameObject[] spawnLocationsList;
    public GameObject smallFruit;
    public GameObject largeFruit;

    // Start is called before the first frame update
    void Start()
    {

        spawnLocationsList = GameObject.FindGameObjectsWithTag("FruitSpawnLocation");

        for ( int i = 0 ; i < fruitCountSpawned ; i++) {
            SpawnFruit();
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void SpawnFruit()
    {
        float randomIndex;
        float coinFlip;
        
            randomIndex = Random.value * 60f;

            if (randomIndex == 60.0f)
            {
                randomIndex--;
            }

            FruitSpawnOccupiedTest test = spawnLocationsList[(int)randomIndex].GetComponent<FruitSpawnOccupiedTest>();

            if (!test.IsOccupied())
            {
                coinFlip = Random.value;
                if (coinFlip < 0.5f)
                {
                    GameObject.Instantiate(smallFruit, spawnLocationsList[(int)randomIndex].transform.position, Quaternion.identity, spawnLocationsList[(int)randomIndex].transform);
                    test.SetOccupation(true);
                }
                else
                {
                    GameObject.Instantiate(largeFruit, spawnLocationsList[(int)randomIndex].transform.position, Quaternion.identity, spawnLocationsList[(int)randomIndex].transform);
                    test.SetOccupation(true);
                }
                
            }
            else
            {
                SpawnFruit();
            }
        }
    
}
