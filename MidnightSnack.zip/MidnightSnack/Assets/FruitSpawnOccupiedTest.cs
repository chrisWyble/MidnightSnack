﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FruitSpawnOccupiedTest : MonoBehaviour
{

    bool locationOccupied = false;

    public bool IsOccupied() {
        return locationOccupied;
    }

    public void SetOccupation(bool state)
    {
        locationOccupied = state;
    }

}
