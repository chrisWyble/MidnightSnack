﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BatBehavior : MonoBehaviour
{

    [Header("Movement variables")]
    public float batSpeed = 1;
    public float positionUpdateTime = 0.01f;
    public float mouseSpeed = 2.0f;
    float xDelta;
    float zDelta;

    [Header("Hunger variables")]
    public Slider hungerSlider;
    [Tooltip("Percentage of hunger lost per second.")]
    public float hungerTick = 0.01f;
    public float maxHunger = 100;
    private float currentHunger;
    public float getHungryTime = 0.01f;

    [Header("NightShade control variables")]
    public RectTransform nightShade;
    public float alphaTick = 0.1f;
    public float alphaTickTime = 0.1f;
    Image nightShadeImage;
    bool echoInProgress = false;
    bool hitZero = false;
    bool echoDone = true;
    public bool enableEcho = true;

    // Start is called before the first frame update
    void Start()
    {
        currentHunger = maxHunger;
        hungerTick = (hungerTick * maxHunger) * getHungryTime; // Recalculating hunger tick to be the actual value that is taken each time GetHungry function is called
        
        xDelta = 0;
        zDelta = 0;

        alphaTick = (alphaTick * alphaTickTime);
        nightShadeImage = nightShade.GetComponent<Image>();

        if (!enableEcho)
        {
            nightShadeImage.color = new Color(0f, 0f, 0f, 0f);
        }

        Invoke("PositionUpdate", positionUpdateTime);
        Invoke("GetHungry",getHungryTime);
    }

    // Update is called once per frame
    void Update()
    {
        float h;
        float angle;

        // Rotation of bat to follow Mouse //
        h = mouseSpeed * Input.GetAxis("Mouse X"); // Gets the current mouse position in the x axis, multiplies it my the mouse sensitivity
        transform.Rotate(0, h, 0); // Sets the bat rotation to the h variable above

        // Setting "speed" of bat in the x and z axes //
        angle = Mathf.Deg2Rad*transform.rotation.eulerAngles.y; // Finds the angle in degrees of the current orintation of the bat in the y axis.
        xDelta = batSpeed * Mathf.Sin(angle); // Imagine we have a right triangle and we use the batSpeed (the hypotenuse in this example) to find the length of the x axis side
        zDelta = batSpeed * Mathf.Cos(angle); // Using the same right triangle to find the length of the z axis side

        if (Input.GetKey(KeyCode.Mouse0) && !echoInProgress && enableEcho) {

            Invoke("Echo", alphaTickTime);

        }
    }

    void PositionUpdate()
    {
        Vector3 holdPos;

        // Actually moving the bat //
        holdPos = transform.position;   // Gets current position of bat
        holdPos.z += zDelta;    // Adjusts position in z axis
        holdPos.x += xDelta;    // Adjusts position in x axis
        transform.position = holdPos; //Updates bat position

        Invoke("PositionUpdate", positionUpdateTime);
    }

    void GetHungry()
    {

        currentHunger -= hungerTick;
        hungerSlider.value = currentHunger;

        Invoke("GetHungry", getHungryTime);

    }

    void Echo()
    {
        echoInProgress = true;

        if (!hitZero)
        {
            echoDone = false;
            nightShadeImage.color = new Color(0f, 0f, 0f, (nightShadeImage.color.a - alphaTick));
        }
        else
        {
            nightShadeImage.color = new Color(0f, 0f, 0f, (nightShadeImage.color.a + alphaTick));
        }

        if (nightShadeImage.color.a < 0)
        {
            hitZero = true;
        }
        else if (nightShadeImage.color.a>1f)
        {
            nightShadeImage.color = new Color(0f, 0f, 0f, 1f);
            echoDone = true;
            hitZero = false;
            echoInProgress = false;
        }

        if (!echoDone)
        {
            Invoke("Echo", alphaTickTime);
        }
        else
        {
            CancelInvoke("Echo");
        }
    }

    /*
    private void OnCollisionEnter(Collision collision)
    {
        print("collision");
        if (collision.gameObject.name == "Leaf (13)") {
            print("collision");
            Vector3 holdPos;

            holdPos = transform.position;
            holdPos.z -= zDelta;
            holdPos.x -= xDelta;
            transform.position = holdPos;
        }

    }
    */
}
