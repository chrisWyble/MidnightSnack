﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BatBehavior : MonoBehaviour
{
    public Camera batView;
    public float batSpeed = 1;
    public float maxHunger = 100;
    private float currentHunger;

    public float PositionUpdateTime = 0.2f;
    public float mouseSpeed = 2.0f;
    float xDelta;
    float zDelta;
    // Start is called before the first frame update
    void Start()
    {
        currentHunger = maxHunger;
        xDelta = 0;
        zDelta = 0;
        Invoke("PositionUpdate", PositionUpdateTime);
    }

    // Update is called once per frame
    void Update()
    {
        float h;
        float angle;

        h = mouseSpeed * Input.GetAxis("Mouse X"); // Gets the current mouse position in the x axis, multiplies it my the mouse sensitivity
        transform.Rotate(0, h, 0); // Sets the bat rotation to the h variable above

        angle = Mathf.Deg2Rad*transform.rotation.eulerAngles.y; // Finds the angle in degrees of the current orintation of the bat in the y axis.
        xDelta = batSpeed * Mathf.Sin(angle); // Imagine we have a right triangle and we use the batSpeed (the hypotenuse in this example) to find the length of the x axis side
        zDelta = batSpeed * Mathf.Cos(angle); // Using the same right triangle to find the length of the z axis side
    }

    void PositionUpdate()
    {
        Vector3 holdPos;

        holdPos = transform.position;   // Gets current position of bat
        holdPos.z += zDelta;    // Adjusts position in z axis
        holdPos.x += xDelta;    // Adjusts position in x axis
        transform.position = holdPos; //Updates bat position

        Invoke("PositionUpdate", PositionUpdateTime);
    }

    /*
    private void OnCollisionEnter(Collision collision)
    {
        print("collision");
        if (collision.gameObject.name == "Leaf (13)") {
            print("collision");
            Vector3 holdPos;

            holdPos = transform.position;
            holdPos.z -= zDelta;
            holdPos.x -= xDelta;
            transform.position = holdPos;
        }

    }
    */
}
