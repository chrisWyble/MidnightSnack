﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BatBehavior : MonoBehaviour
{

    [Header("Movement variables")]
    bool batPaused = true;
    public float batSpeed = 1;
    public float positionUpdateTime = 0.01f;
    public float mouseSpeed = 2.0f;
    bool collisionOccurred = false;
    float collisionAngleMin;
    float collisionAngleMax;
    float currentAngle;
    float xDelta;
    float zDelta;

    [Header("Hunger variables")]
    public Slider hungerSlider;
    [Tooltip("Percentage of hunger lost per second.")]
    public float hungerTick = 0.01f;
    public float maxHunger = 100;
    private float currentHunger;
    public float getHungryTime = 0.01f;

    [Header("NightShade control variables")]
    public RectTransform nightShade;
    public float alphaTick = 0.1f;
    public float alphaTickTime = 0.1f;
    Image nightShadeImage;
    bool echoInProgress = false;
    bool hitZero = false;
    bool echoDone = true;
    [Tooltip("Allows us to disable Night Shade for testing purposes.")]
    public bool enableEcho = true;

    [Header("Score control variables")]
    public Text scoreValue;
    public float largeFruitValue = 20.0f;
    public float smallFruitValue = 10.0f;

    [Header("Forest object")]
    public GameObject forest;

    bool fruitCollision = false;


    // Start is called before the first frame update
    void Start()
    {
        currentHunger = maxHunger;
        hungerTick = (hungerTick * maxHunger) * getHungryTime; // Recalculating hunger tick to be the actual value that is taken each time GetHungry function is called

        currentAngle = 0f;
        xDelta = 0f;
        zDelta = 0f;

        alphaTick = (alphaTick * alphaTickTime); // Recalculating alpha tick to be the actual value that is taken each time Echo function is called
        nightShadeImage = nightShade.GetComponent<Image>();
        if (!enableEcho)
        {
            nightShadeImage.color = new Color(0f, 0f, 0f, 0f); // Sets Night Shade to transparent for testing purposes
        }

        Invoke("PositionUpdate", positionUpdateTime);
        Invoke("GetHungry",getHungryTime);
    }

    // Update is called once per frame
    void Update()
    {
        float angle;

        // Rotation of bat to follow Mouse //
        if (!batPaused)
        {
            angle = mouseSpeed * Input.GetAxis("Mouse X"); // Gets the current mouse position in the x axis, multiplies it my the mouse sensitivity
            transform.Rotate(0f, angle, 0f); // Sets the bat rotation to the h variable above


            // Setting "speed" of bat in the x and z axes //

            currentAngle = Mathf.Deg2Rad * transform.rotation.eulerAngles.y; // Finds the angle in degrees of the current orintation of the bat in the y axis.
            xDelta = batSpeed * Mathf.Sin(currentAngle); // Imagine we have a right triangle and we use the batSpeed (the hypotenuse in this example) to find the length of the x axis side
            zDelta = batSpeed * Mathf.Cos(currentAngle); // Using the same right triangle to find the length of the z axis side

            if (collisionOccurred && (currentAngle * Mathf.Rad2Deg < collisionAngleMin || currentAngle * Mathf.Rad2Deg > collisionAngleMax))
            {
                collisionOccurred = false;
            }

            //  Enabling echo as well as triggering on Mouse 1 (even though the key code is mouse0)
            if (Input.GetKey(KeyCode.Mouse0) && !echoInProgress && enableEcho)
            {

                Invoke("Echo", alphaTickTime);

            }
        }
    }

    void PositionUpdate()
    {
        Vector3 holdPos;

        // Actually moving the bat //
        holdPos = transform.position;   // Gets current position of bat
        if (!collisionOccurred && !batPaused)
        {
            holdPos.z += zDelta;    // Adjusts position in z axis
            holdPos.x += xDelta;    // Adjusts position in x axis
        }
        holdPos.y = 45f; // Keeps bat at 45 y level
        transform.position = holdPos; //Updates bat position
        

        Invoke("PositionUpdate", positionUpdateTime);
    }

    void GetHungry()
    {
        if (!batPaused) {
            currentHunger -= hungerTick;    // Lowers currentHunger
            hungerSlider.value = currentHunger; // Updates hunger slider
        }

        Invoke("GetHungry", getHungryTime);

    }

    void Echo()
    {
        echoInProgress = true; // Control variable to not allow spamming of echo

        if (!hitZero)   // Makes Night Shade more transparent until it hits 0
        {
            echoDone = false;
            nightShadeImage.color = new Color(0f, 0f, 0f, (nightShadeImage.color.a - alphaTick));
        }
        else // Makes Night Shade less transparent until it hits 1
        {
            nightShadeImage.color = new Color(0f, 0f, 0f, (nightShadeImage.color.a + alphaTick));
        }

        if (nightShadeImage.color.a < 0)
        {
            hitZero = true; // Control variable that alternates Night Shade from becoming more transparent to less transparent
        }
        else if (nightShadeImage.color.a>1f)
        {
            nightShadeImage.color = new Color(0f, 0f, 0f, 1f); // Once echo is over set color alpha back to 1 and reset control variables
            echoDone = true;
            hitZero = false;
            echoInProgress = false;
        }

        if (!echoDone)
        {
            Invoke("Echo", alphaTickTime);
        }
        else
        {
            CancelInvoke("Echo"); // Need this becuase it was looping echos for another 5 or so cycles
        }
    }

    
    private void OnCollisionEnter(Collision collision)
    {
        if (!collisionOccurred && collision.gameObject.name == "Leaf (13)") {
            Vector3 holdPos;
            float colAngle;
            
            collisionOccurred = true;
            collisionAngleMax = currentAngle + 90f;
            collisionAngleMin = currentAngle - 90f;
            holdPos = transform.position;
            colAngle = Mathf.Atan((collision.gameObject.transform.position.z-transform.position.z)/(collision.gameObject.transform.position.x - transform.position.x));
            holdPos.z -= 1.5f * Mathf.Cos(colAngle);
            holdPos.x -= 1.5f * Mathf.Sin(colAngle);
            holdPos.y = 45f; // Keeps bat at 45 y level

            //print(holdPos.z);
            //print(holdPos.x);

            transform.position = holdPos;
        }
        else if (!fruitCollision && collision.gameObject.tag == "LargeFruit")
        {

            fruitCollision = true;

            // Adjust Score
            float newScore = float.Parse(scoreValue.GetComponent<Text>().text) + largeFruitValue; // Adjusting score based on fruit type
            scoreValue.GetComponent<Text>().text = newScore.ToString();

            // Adjust Hunger

            if (currentHunger + largeFruitValue <=100.0f) {
                currentHunger += largeFruitValue; // Updating hunger slider value
            }
            else
            {
                newScore = float.Parse(scoreValue.GetComponent<Text>().text) + (int) (currentHunger + largeFruitValue-100.0f); // Bonus points for overflow hunger points
                scoreValue.GetComponent<Text>().text = newScore.ToString();
                currentHunger = 100.0f; // Making sure slider value doesn't go over max 
            }

            // Remove Fruit
            collision.gameObject.GetComponentInParent<FruitSpawnOccupiedTest>().SetOccupation(false);
            GameObject.Destroy(collision.gameObject);
            forest.GetComponent<ForestBehavior>().SpawnFruit();

            Invoke("ResetFruitCollision",0.1f);

        }
        else if (!fruitCollision && collision.gameObject.tag == "SmallFruit")
        {

            fruitCollision = true;

            // Adjust Score
            float newScore = float.Parse(scoreValue.GetComponent<Text>().text) + smallFruitValue; // Adjusting score based on fruit type
            scoreValue.GetComponent<Text>().text = newScore.ToString();

            // Adjust Hunger

            if (currentHunger + smallFruitValue <= 100.0f)
            {
                currentHunger += smallFruitValue; // Updating hunger slider value
            }
            else
            {
                newScore = float.Parse(scoreValue.GetComponent<Text>().text) + (int) (currentHunger + smallFruitValue - 100.0f); // Bonus points for overflow hunger points
                scoreValue.GetComponent<Text>().text = newScore.ToString();
                currentHunger = 100.0f; // Making sure slider value doesn't go over max 
            }

            // Remove Fruit
            collision.gameObject.GetComponentInParent<FruitSpawnOccupiedTest>().SetOccupation(false);
            GameObject.Destroy(collision.gameObject);
            forest.GetComponent<ForestBehavior>().SpawnFruit();

            Invoke("ResetFruitCollision", 0.1f);

        }

    }

    void ResetFruitCollision()
    {
        fruitCollision = false;
    }

    public void SetPause(bool state)
    {
        batPaused = state;
    }
    
}
