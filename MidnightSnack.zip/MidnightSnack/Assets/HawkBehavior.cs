﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HawkBehavior : MonoBehaviour
{

    [Header("Movement variables")]
    bool hawkPaused = false;
    public float hawkSpeed = 1f;
    public float positionUpdateTime = 0.01f;
    Vector3 currentDestinationFar;  // gives waypoint to wander towards across the map
    Vector3 currentDestinationClose;    // allows for waypoints closer to hawk to simulate wandering so the hawk isnt going directly towards the "far"  destination 
    float xDelta = 0f;
    float zDelta = 0f;

    // Start is called before the first frame update
    void Start()
    {
        
        NewDestinationFar(new Vector3(0f,45f,0f));

        print(currentDestinationFar);
        print("New Close: " + currentDestinationClose);

        Invoke("PositionUpdate", positionUpdateTime);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void PositionUpdate()
    {
        Vector3 holdPos;

        // Actually moving the hawk //
        holdPos = transform.position;   // Gets current position of hawk
        if (!hawkPaused)
        {
            holdPos.z += zDelta;    // Adjusts position in z axis
            holdPos.x += xDelta;    // Adjusts position in x axis
        }
        transform.position = holdPos; //Updates hawk position

        if ((transform.position - currentDestinationFar).magnitude < 5f)
        {
            NewDestinationFar();
            print("New Far: " + currentDestinationFar);
            print("far");
        }
        else if ((transform.position - currentDestinationClose).magnitude < 2f)
        {
            NewDestinationClose();
            print("New Close: " + currentDestinationClose);
            print("close");
        }


        Invoke("PositionUpdate", positionUpdateTime);
    }

    void NewDestinationClose()
    {
        float holdz, holdx, farAngle, closeAngle, dist;

        transform.LookAt(currentDestinationFar);
        farAngle = transform.eulerAngles.y;
        //print("Far angle: " + farAngle);
        closeAngle = ((Random.value * 30f) - 15f +farAngle);
        //print("Close angle: " + closeAngle);
        //print("far distance: " + Vector3.Distance(currentDestinationFar, transform.position));
        //print("current Pos: " + transform.position);
        if ((currentDestinationFar - transform.position).magnitude < 30f)
        {
            dist = (currentDestinationFar - transform.position).magnitude;
        }
        else
        {
            dist = Random.value * (currentDestinationFar - transform.position).magnitude;
        }
        //print("dist: " + dist);
        holdx = transform.position.x + dist * Mathf.Cos((closeAngle + 90f) * Mathf.Deg2Rad);
        holdz = transform.position.z + dist * Mathf.Sin((closeAngle + 90f) * Mathf.Deg2Rad);

        xDelta = hawkSpeed * Mathf.Cos((closeAngle + 90f) * Mathf.Deg2Rad);
        zDelta = hawkSpeed * Mathf.Sin((closeAngle + 90f) * Mathf.Deg2Rad);

        transform.LookAt(new Vector3(holdx, 45f, holdz));
        currentDestinationClose = new Vector3(holdx ,45f , holdz);
    }

    void NewDestinationFar()
    {
        currentDestinationFar = new Vector3(Random.value * 500f - 250f, 45f , Random.value * 500f - 250f);
        NewDestinationClose();
    }

    public void NewDestinationFar(Vector3 dest)
    {
        currentDestinationFar = dest;
        NewDestinationClose();
    }

    public void SetPause(bool state)
    {
        hawkPaused = state;
    }
}
