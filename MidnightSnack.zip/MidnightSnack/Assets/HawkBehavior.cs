﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HawkBehavior : MonoBehaviour
{

    [Header("Movement variables")]
    public bool hawkPaused = true;
    public float hawkSpeed = 1f;
    public float positionUpdateTime = 0.01f;
    Vector3 currentDestinationFar;  // gives waypoint to wander towards across the map
    Vector3 currentDestinationClose;    // allows for waypoints closer to hawk to simulate wandering so the hawk isnt going directly towards the "far"  destination 

    [Header("Echo Sensitivity variables")]
    public float sensitivityCount = 5f;
    float sensitivityMax; 
    public float sensitivityCountTime = 3f;

    // Start is called before the first frame update
    void Start()
    {

        sensitivityMax = sensitivityCount;
        
        NewDestinationFar();

        Invoke("AdjustSensitivity", sensitivityCountTime);
        Invoke("PositionUpdate", positionUpdateTime);
    }

    // Update is called once per frame
    void Update()
    {

    }

    void PositionUpdate()
    {         
        if (!hawkPaused)
        {
            transform.position = Vector3.MoveTowards(transform.position,currentDestinationClose,hawkSpeed*Time.deltaTime);
        }

        if (transform.position == currentDestinationFar)
        {
            NewDestinationFar();
        }
        else if (transform.position == currentDestinationClose)
        {
            NewDestinationClose();
        }

        Invoke("PositionUpdate", positionUpdateTime);
    }

    void NewDestinationClose()
    {
        float holdz, holdx;

        if (transform.position.x < currentDestinationFar.x)
        {
            holdx = Random.Range(transform.position.x, currentDestinationFar.x);
        }
        else
        {
            holdx = Random.Range(currentDestinationFar.x, transform.position.x);
        }

        if (transform.position.z < currentDestinationFar.z)
        {
            holdz = Random.Range(transform.position.z, currentDestinationFar.z);
        }
        else
        {
            holdz = Random.Range(currentDestinationFar.z, transform.position.z);
        }

        if ((currentDestinationFar - transform.position).magnitude < 30f)
        {
            transform.LookAt(currentDestinationFar);
            currentDestinationClose = currentDestinationFar;
        }
        else
        {
            transform.LookAt(new Vector3(holdx, 45f, holdz));
            currentDestinationClose = new Vector3(holdx, 45f, holdz);
        }

        //print("--------------------");
        //print("Current Far: " + currentDestinationFar);
        //print("Current Close: " + currentDestinationClose);
        //print("--------------------");

    }

    void NewDestinationFar()
    {
        currentDestinationFar = new Vector3(Random.Range(-250f,250f), 45f , Random.Range(-250f, 250f));
        NewDestinationClose();
    }

    public void NewDestinationFar(Vector3 dest)
    {
        Vector3 holdDest;

        holdDest = new Vector3(dest.x + Random.Range(-sensitivityCount * 20f, sensitivityCount * 20f), 45f, dest.z + Random.Range(-sensitivityCount * 20f,sensitivityCount *20f));
        if (sensitivityCount != 0) { sensitivityCount--; }

        //print("Estimate: " + holdDest);
        //print("Actual: " + dest);

        //print(sensitivityCount);
        CancelInvoke("AdjustSensitivity");
        Invoke("AdjustSensitivity", sensitivityCountTime);
        currentDestinationFar = dest;
        NewDestinationClose();
    }

    void AdjustSensitivity()
    {
        if (sensitivityCount != sensitivityMax) { sensitivityCount++; }
        //print(sensitivityCount);
        Invoke("AdjustSensitivity", sensitivityCountTime);
    }

    public void SetPause(bool state)
    {
        hawkPaused = state;
    }
}
