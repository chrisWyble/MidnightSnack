﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TimerScript : MonoBehaviour
{

    float minutes;
    public float resetMinutes = 5.0f;
    float seconds = 59.0f;
    Text timerValue;
    bool timerPaused = true;


    // Start is called before the first frame update
    void Start()
    {
        timerValue = this.GetComponent<Text>();
        minutes = resetMinutes-1.0f;
    }

    // Update is called once per frame
    void Update()
    {
        if (!timerPaused)
        {
            seconds -= Time.deltaTime;
            if (seconds < 0.0f)
            {
                minutes--;
                if (!(minutes == 0.0f))
                {
                    seconds = 59.0f;
                }
                else
                {

                }
            }
            timerValue.text = minutes.ToString() + ":" + seconds.ToString("f0");
        }
    }

    public void SetPause(bool state)
    {
        timerPaused = state;
    }
}
