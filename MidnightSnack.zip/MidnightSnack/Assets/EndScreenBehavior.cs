﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class EndScreenBehavior : MonoBehaviour
{

    public Canvas endScreen;
    public Canvas gameOverlay;
    public Text status;
    public Text score;

    public void GameOver(bool state ,bool lostCondition, string scoreValue)
    {
        if (state)
        {
            status.text = "Game Won!";
        }
        else
        {
            if (lostCondition)
            {
                status.text = "Game Lost!\nReason: Eaten by Hawk";
            }
            else
            {
                status.text = "Game Lost!\nReason: Starved to Death";
            }
        }

        score.text = "Score: " + scoreValue;

        endScreen.gameObject.SetActive(true);
        gameOverlay.gameObject.SetActive(false);
    }
}
